self.assetsManifest = {
  "version": "+fGUvbBB",
  "assets": [
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-tKVwwWc/4VAeq3H8KW55mf/RSwkvQWZAxZ5+ycidfIA=",
      "url": "404.html"
    },
    {
      "hash": "sha256-iW1ESI3Jkg0V+SNvMv9f+4DI+YtP/ICAhiwttzqPsjE=",
      "url": "_content/PaddleRcl/PaddleRcl.js"
    },
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4/sNPbaRUspOLefkCY=",
      "url": "_content/PaddleRcl/background.png"
    },
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4/sNPbaRUspOLefkCY=",
      "url": "_content/SupabaseRcl/background.png"
    },
    {
      "hash": "sha256-oaBkxh3zsOtiDlJ75o4d6WBDcygbR8Ri4KGzyJL6Qnw=",
      "url": "_content/SupabaseRcl/supabaseAuth.js"
    },
    {
      "hash": "sha256-udWk5lOVlS6bca3rKZsP+S8eG/F+aMNsNfJ1vQsuXl0=",
      "url": "_framework/EmineoBlazor.ve7bgos8y8.wasm"
    },
    {
      "hash": "sha256-vMGMZ+nYtzu5YTzlXSi8fkFf7SEos8SLx7v2ZAboVnQ=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.s61l976zip.wasm"
    },
    {
      "hash": "sha256-q9iTjnNpnzW/BZ461oww5jdlSQAR74ZePbCj0bLpDE0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.dulb0pij4i.wasm"
    },
    {
      "hash": "sha256-v+30TYenrusN9RLDGuJtOMPiKZBjo/MlNMJXsPfdwjo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.f8h2e3jhs0.wasm"
    },
    {
      "hash": "sha256-B1WEnxzCf+FXAm0YExjEDtwoi4W1yTSCp31+IDiMqvs=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.rv94yiqru5.wasm"
    },
    {
      "hash": "sha256-DwG60CkH4jdlhCYe6ofZmwR/FabAMjgH2jcTaP4RbAg=",
      "url": "_framework/Microsoft.AspNetCore.Components.fc1lvq6i9q.wasm"
    },
    {
      "hash": "sha256-MoN9NnDJWaJscXqbjdtujiUJfibQ7TUX/1iBdY0LipQ=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.i8sp0u7u7s.wasm"
    },
    {
      "hash": "sha256-eeTikqmiucc9fV041AZcqQRyEh1lmW+VwDDzgdOZc4Y=",
      "url": "_framework/Microsoft.CSharp.l9qyjq59b2.wasm"
    },
    {
      "hash": "sha256-oDcpyYbqdkq6hP6NijTRWyXx2c2DKL6qilKSIzNmK3I=",
      "url": "_framework/Microsoft.Extensions.Configuration.47mkb8d5uo.wasm"
    },
    {
      "hash": "sha256-ZMSiWFGZbJVZPj28eku0yZNbnGhFfzFj6gpep+3y9tw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.488ris6j7m.wasm"
    },
    {
      "hash": "sha256-o5L9N1UOhqfOacmjcz9QfaqDLjHJf5HS/F+zQk1y9Ko=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.tsl8t8fg2u.wasm"
    },
    {
      "hash": "sha256-0QgfxLVKEcY1GdWiUa+Fjm19k+7QKaI+J/PxuV5NJbY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.p6qd7jvb0a.wasm"
    },
    {
      "hash": "sha256-HA794oey9tnbxPmEPxnLeVpNnd9Ez3NCmXHHuP961+Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.cum1owb24o.wasm"
    },
    {
      "hash": "sha256-/DwMjCWLivRtVrr4ak/cjUZWXjaUdb3fwR3h0hIIH0Y=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.ox8zpfpx01.wasm"
    },
    {
      "hash": "sha256-7jpTpoeaqeTCO4/BIz4KTkxXO1jTvtord2+Qg24nbfI=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.aywdphonwj.wasm"
    },
    {
      "hash": "sha256-2AgfdNasmRc+E1koCtR58BJFQi84rqacFR2JSeaaBSk=",
      "url": "_framework/Microsoft.Extensions.Http.84ks8389da.wasm"
    },
    {
      "hash": "sha256-1ANrm+l31Cf2c68e1aXOYXovdTei3c5J9jMMYLuoSOk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.4acocf88mw.wasm"
    },
    {
      "hash": "sha256-q+ooWLfUUVonFc8mpUDBQ6tCEf1kdKa3ZRUIvqWX/yM=",
      "url": "_framework/Microsoft.Extensions.Logging.vrc80usgm9.wasm"
    },
    {
      "hash": "sha256-l/nD98hte074xC7HtxqKghuxIyGN4Vj1jRhUr9t1vfo=",
      "url": "_framework/Microsoft.Extensions.Options.x6bn6qcxic.wasm"
    },
    {
      "hash": "sha256-rxHDRuDvkgr8ovvNhTAPo1R77aaj2ZdbtB1UhGxSITk=",
      "url": "_framework/Microsoft.Extensions.Primitives.53666huos5.wasm"
    },
    {
      "hash": "sha256-hhE+p8W36Xt5rxWVHZKZwIPWrKuVoVC5qqRxOCvdPtY=",
      "url": "_framework/Microsoft.IO.RecyclableMemoryStream.yxkatvvqoa.wasm"
    },
    {
      "hash": "sha256-7sCN4qXB33/ef65J9QK/+YNUoXCtWBdBT2EF1FgMeiQ=",
      "url": "_framework/Microsoft.IdentityModel.Abstractions.248sngnkb1.wasm"
    },
    {
      "hash": "sha256-s4PcUGVsWd3RawK+erm+TTtlaW7lKCGUikybScse+Fs=",
      "url": "_framework/Microsoft.IdentityModel.JsonWebTokens.do6a07o59u.wasm"
    },
    {
      "hash": "sha256-6ynDAQ1sEe2EfKrc8n7lUjD8dccDe5hetAmGPxpTKqc=",
      "url": "_framework/Microsoft.IdentityModel.Logging.l0c9d5hrv1.wasm"
    },
    {
      "hash": "sha256-007xuDnm4v+hMpJrxaWzOijbGgrD3RuurnF/l4ibZEQ=",
      "url": "_framework/Microsoft.IdentityModel.Tokens.tgxjdpx9cv.wasm"
    },
    {
      "hash": "sha256-SdDwaM6UI8kXw2KggcDXOka9rpiGR9i+JIAMM70YTJY=",
      "url": "_framework/Microsoft.JSInterop.5555vye4d4.wasm"
    },
    {
      "hash": "sha256-tWu37j/RoE6Pwu6s46idTVIaPuEWCkAbsWSyzgKFWXI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.vjcfjtelwd.wasm"
    },
    {
      "hash": "sha256-CMXcRIg84k7AstbhcD8rbnPKy2wa/gmsBD8gBgZP1c8=",
      "url": "_framework/MimeMapping.gmxjevqz69.wasm"
    },
    {
      "hash": "sha256-GlXMWKvDs45M2pACoR3Y4Qh8mcrOZGljqmvJY+6JZ5s=",
      "url": "_framework/Newtonsoft.Json.qkbufwhni2.wasm"
    },
    {
      "hash": "sha256-wMPUG5cgDbQhW1b845XJGcW1hk8MeyMU3h/icNrw4i0=",
      "url": "_framework/PaddleRcl.0s17jza3re.wasm"
    },
    {
      "hash": "sha256-jUEh1mM6mkGdyQrEwowAbpQ8R148PZIAUIOXn0mrgIA=",
      "url": "_framework/Supabase.Core.zcuz262cdn.wasm"
    },
    {
      "hash": "sha256-i3baKTpUA4voBHgpG1KCEXhOQom7BsRz3N4FCywsZ6k=",
      "url": "_framework/Supabase.Functions.das9utiwul.wasm"
    },
    {
      "hash": "sha256-fIDLwe2YAl/vphQoUtljCM5aRD5nbL3EXYlszJRLyfw=",
      "url": "_framework/Supabase.Gotrue.kcc8v0x814.wasm"
    },
    {
      "hash": "sha256-XBrmcfBn9P/tWxdOP8BZzt+Er2JFu2K3zhAWYTFDah0=",
      "url": "_framework/Supabase.Postgrest.c2dibacbnw.wasm"
    },
    {
      "hash": "sha256-uVv6E6kYwaHrayuVaV9LCt6rkkyLzb8yruwLcdoZP3o=",
      "url": "_framework/Supabase.Realtime.r7rezo8ln8.wasm"
    },
    {
      "hash": "sha256-y76yu8B80Dx0eKBpLW7a6YC2em2J/O6ww8+m80LzhXE=",
      "url": "_framework/Supabase.Storage.rox9ole9mr.wasm"
    },
    {
      "hash": "sha256-zig+I7dVOmC5X90UX+XkfblaDBDqC28AFjl2khOCN/s=",
      "url": "_framework/Supabase.qyt6qogdl5.wasm"
    },
    {
      "hash": "sha256-pwrE3vXLII3JlJ/uEj9kBHkiJ3YgznCX3wIhHA5o0bU=",
      "url": "_framework/SupabaseRcl.xm2kzm9420.wasm"
    },
    {
      "hash": "sha256-vPEm2KqgXqruGwnz718iSgmDoB8Img7iH3FzO57b0Rg=",
      "url": "_framework/System.400l3mulw9.wasm"
    },
    {
      "hash": "sha256-Ohk0Qgup8Bo9LdsZ8q1T0hKd9G8U+kb1Cso297LBOhY=",
      "url": "_framework/System.Collections.Concurrent.uj3ls2nzxp.wasm"
    },
    {
      "hash": "sha256-b/nEoPWSmQ2cfmG67000v0h8JsFOGnfPPkIJlV106WA=",
      "url": "_framework/System.Collections.Immutable.lrrwuxbgmx.wasm"
    },
    {
      "hash": "sha256-eUDPYyIZRaMUil3gKJMALqTJT/3XRcodfYBhW3ojquk=",
      "url": "_framework/System.Collections.NonGeneric.1yj2rhtbvl.wasm"
    },
    {
      "hash": "sha256-qh6wVj2rVZ3yY6IuS+1+HJ9XJD45nbr+GfB5exud9J8=",
      "url": "_framework/System.Collections.Specialized.qzpr9fq18m.wasm"
    },
    {
      "hash": "sha256-KbaTBhMfVVzH+0lpi0R99CmPCyTNAJK4TyoBiTD8iR4=",
      "url": "_framework/System.Collections.r3pzcphhzg.wasm"
    },
    {
      "hash": "sha256-bEbJTeEIMRQ8rPVInntERkwlCongDDfRrzw5vQts8h0=",
      "url": "_framework/System.ComponentModel.Primitives.ke6s70xvrb.wasm"
    },
    {
      "hash": "sha256-2nyGYvaZF/qlLt38m7ESAf7apfzzFZW/iSEfpfhcJZ4=",
      "url": "_framework/System.ComponentModel.TypeConverter.uiwqwzhj7i.wasm"
    },
    {
      "hash": "sha256-eIa8P9d6+k7PI95giXJV/uZ+Q/Kg4vxkRI2Z0S+DWL0=",
      "url": "_framework/System.ComponentModel.s7fa23eokj.wasm"
    },
    {
      "hash": "sha256-/TYvEmPhuFwcHs+2XJMjMgbhgdnaBap5yxos3lznIIs=",
      "url": "_framework/System.Console.pddx5whfxb.wasm"
    },
    {
      "hash": "sha256-nUxCdeWSd38TZgEs51zHZ0ophwpOGt1XOgxS1ZIc2zY=",
      "url": "_framework/System.Data.Common.lyc85pn7gl.wasm"
    },
    {
      "hash": "sha256-nLqoUHwbXJ6vxFsSMxT5g9imn/6rSJfsc2qiCZhxioA=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.8r167sacsi.wasm"
    },
    {
      "hash": "sha256-ipX+Fn/4zXaDOQVTPe2RhaJ7HLcBiXiH//++tVp/ZxE=",
      "url": "_framework/System.Diagnostics.TraceSource.avpinowds8.wasm"
    },
    {
      "hash": "sha256-KIET+Xd45kYy3tfGADe3n3dY83Ck1paVvho4t0ETZSo=",
      "url": "_framework/System.Diagnostics.Tracing.0m9mzhgjqt.wasm"
    },
    {
      "hash": "sha256-yj2twp6uQgajcqFShoFn2NgsEgSdwvcN9EYaq92sQxk=",
      "url": "_framework/System.Drawing.Primitives.afpmoclusu.wasm"
    },
    {
      "hash": "sha256-NFpXLgCTsyBU+AK+27QTsQQxyAoaLo/HDVh9RRvDIL4=",
      "url": "_framework/System.Drawing.c6tmp1gjc8.wasm"
    },
    {
      "hash": "sha256-gWDqR1lNXFd7UwaJj+wvIAbYBz73Pdo1FtNlB1TdtH0=",
      "url": "_framework/System.Formats.Asn1.h0fq6rguio.wasm"
    },
    {
      "hash": "sha256-QxBi/QA/PNIOE5qA4JxKnaIHIkYZMPBH+FL/1QkDFYA=",
      "url": "_framework/System.IO.Compression.7b3esric1w.wasm"
    },
    {
      "hash": "sha256-fZpB2NFmoDJXAqnCYU4+XAKkZbE51ViM3KsQ+bxqVOo=",
      "url": "_framework/System.IO.Pipelines.px0vglstfo.wasm"
    },
    {
      "hash": "sha256-PO+x96C/PkZ0SBbU+a9mIaUKvAK79n200oqZ/t+TxrE=",
      "url": "_framework/System.IdentityModel.Tokens.Jwt.8p36zpd3sm.wasm"
    },
    {
      "hash": "sha256-fS4EVwVM8yxirGjaWjWGeoU/IrXu0YOcue/OYWGLCgc=",
      "url": "_framework/System.Linq.Expressions.tsjp2v6ag3.wasm"
    },
    {
      "hash": "sha256-ZC+dopWv/h440Vl6Kx8jucKpJQP4t0SKx6qbOz4/ta8=",
      "url": "_framework/System.Linq.wllgy7kdpo.wasm"
    },
    {
      "hash": "sha256-IBnTD1L91CnO/y0gTvk8W8XwO53YQBdNLhZnI5sP2XA=",
      "url": "_framework/System.Memory.4zvcm9aua1.wasm"
    },
    {
      "hash": "sha256-Ab9JdjCx/xILeQ+oh0KQnOATXZnE7imCalDchroriWc=",
      "url": "_framework/System.Net.Http.Json.pi68gf014q.wasm"
    },
    {
      "hash": "sha256-nHXCh0uyWEp7wnzi+Dz+8q0rlwoZ0Nx0tILUA2r26/w=",
      "url": "_framework/System.Net.Http.csefl2sdx6.wasm"
    },
    {
      "hash": "sha256-LrwSdNDyyF3HPOVAXy0ATqEF7FsrIDN/AN0ZJBeJpto=",
      "url": "_framework/System.Net.NetworkInformation.elp5n3plgu.wasm"
    },
    {
      "hash": "sha256-dgh1J2+E0g8Hc+3O5PmNNsmTgzhxyq6XyUe0ATvpJhU=",
      "url": "_framework/System.Net.Ping.mgmj0k8r9k.wasm"
    },
    {
      "hash": "sha256-9cDVCvkvHd8l5oQOJSNUxETFado2VjBzK8ZR7z0Z8IU=",
      "url": "_framework/System.Net.Primitives.xtwzg84v7o.wasm"
    },
    {
      "hash": "sha256-lIbSKceNl2fud3vRkFbO2fW5Wm27esLJc6DwfwKzN2k=",
      "url": "_framework/System.Net.WebSockets.Client.4efibskx5d.wasm"
    },
    {
      "hash": "sha256-PhnzPEHtWvKcsbolevMJ2wZVHzDcz93RNNTpZtij+OU=",
      "url": "_framework/System.Net.WebSockets.u1ktkmbqxh.wasm"
    },
    {
      "hash": "sha256-enMXypu7e+sYVx5/e8m/sWReg0zPW5ZZtw0LaQNqf5U=",
      "url": "_framework/System.ObjectModel.a0vq4su4zd.wasm"
    },
    {
      "hash": "sha256-XRwQLq3uzj2ObITtwd0l9pl5x13prqwiIVZDTwohJ8w=",
      "url": "_framework/System.Private.CoreLib.34lf7pidr9.wasm"
    },
    {
      "hash": "sha256-hgFFzTmxpqtGiQTfv96ErZk4PJNEzfHzmDWUMn1raoI=",
      "url": "_framework/System.Private.Uri.64jvjvohu9.wasm"
    },
    {
      "hash": "sha256-NPW09msV3VuWlo+Opxkcc7Yzi4huK839M5+JMat99ms=",
      "url": "_framework/System.Private.Xml.Linq.wzodjyxm2t.wasm"
    },
    {
      "hash": "sha256-HI+C3wYbZB2s+ee+W3sU55u9o/cLDmy7dKIxPlj9W8s=",
      "url": "_framework/System.Private.Xml.s6v8d9n78h.wasm"
    },
    {
      "hash": "sha256-M1qwOZIHNQ04r3Rz7QHjFuhGjGZnf98uUS1F0+Oe2PI=",
      "url": "_framework/System.Reactive.vly4ehyc64.wasm"
    },
    {
      "hash": "sha256-uv4IRXbCnLjb6RSm68UE1B51lEAjEshWUdwVrAgYVg8=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.qjk1z49z4z.wasm"
    },
    {
      "hash": "sha256-fy+wN9mbUBdeCRP1jFWwc8hGeCtD9zAWI/uir0tevn0=",
      "url": "_framework/System.Reflection.Emit.Lightweight.b1x1ic91s4.wasm"
    },
    {
      "hash": "sha256-DtvUByUM7iugi+iZbOUqRTAFa9/57eM6sEANIyhYeI4=",
      "url": "_framework/System.Reflection.Primitives.y0t06ffh5m.wasm"
    },
    {
      "hash": "sha256-vewFTGYJ6sqGHLRhNEiGUx/yYornqXSIciph1rcmjrk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.nfpi6j529e.wasm"
    },
    {
      "hash": "sha256-YLVLbOU3qOIiNzRxR8EGME6dzUvZ5zvv2zPp3ZabpG8=",
      "url": "_framework/System.Runtime.InteropServices.wgcpuvrdzb.wasm"
    },
    {
      "hash": "sha256-5esW+cAPZvaOtrKU+95VwlHWcmoG1zYeJ1MfidcFRNc=",
      "url": "_framework/System.Runtime.Numerics.3m0offb1g9.wasm"
    },
    {
      "hash": "sha256-U+fJqRnd9Td/HQ7LQ9tHwaLDvYjj+cVdSV5PFwYiJFo=",
      "url": "_framework/System.Runtime.Serialization.Formatters.vdanj49dzd.wasm"
    },
    {
      "hash": "sha256-9qHCcFb1+uzrIai2+AQJ0U23B15QjgKG+L/enDfmTT4=",
      "url": "_framework/System.Runtime.Serialization.Primitives.6tbtxnc17n.wasm"
    },
    {
      "hash": "sha256-vEsjMNi1tb8obaruHq1rzSwuZirXYKNz8cBhq3DZLEM=",
      "url": "_framework/System.Runtime.oxwk88cqrw.wasm"
    },
    {
      "hash": "sha256-THVmRPnvwt5ZFeOAruZWrDfwuBkZaV3pJtfoe+3vLTA=",
      "url": "_framework/System.Security.Claims.c8qutuqqkz.wasm"
    },
    {
      "hash": "sha256-I1kTrs5xdhjBRkVkVK2ousmT2eDD/L4tjNiZl9o/YpI=",
      "url": "_framework/System.Security.Cryptography.tg8cxw79cf.wasm"
    },
    {
      "hash": "sha256-xlzDXaEN8BlJZ/cmxpvjDbpYqmXAnU9S7pNhE10wL74=",
      "url": "_framework/System.Text.Encoding.Extensions.ajdtrmih3n.wasm"
    },
    {
      "hash": "sha256-B4zxmviAe8R0IpR9gAfEzLDh+OGCoDRsyQc4J5sGFWM=",
      "url": "_framework/System.Text.Encodings.Web.39ki9f5v5l.wasm"
    },
    {
      "hash": "sha256-98YXXQ3rgOEIs+3CsD0NSF9q4M8kMRV+fZE8vCViA7Q=",
      "url": "_framework/System.Text.Json.furcf8a6tg.wasm"
    },
    {
      "hash": "sha256-j14hjO7b8pKeRZKgd4uI5MYFH9MSbcQYEu2jzkVD3Pk=",
      "url": "_framework/System.Text.RegularExpressions.dhwk43t2k1.wasm"
    },
    {
      "hash": "sha256-kBfR7mRpfLrW2joaE9u4vw4dprYTe+RXlogeoXx9idg=",
      "url": "_framework/System.Threading.8ak7qnz1xz.wasm"
    },
    {
      "hash": "sha256-QfErhGrgZoFSJqL8pQvxERwn5Ngn80b19E8Dui5q05s=",
      "url": "_framework/System.Threading.Channels.td9fwtmoz9.wasm"
    },
    {
      "hash": "sha256-igWF5KGLIDTBtOmG1WRw50UQjDatbj2GUUH+rigW5M8=",
      "url": "_framework/System.Threading.Thread.uu6fezbt67.wasm"
    },
    {
      "hash": "sha256-Su9vKuJsmeFUc3TuVxHykaDF/3XkMEMgKDsQRDB+lQs=",
      "url": "_framework/System.Web.HttpUtility.2i03iqplwy.wasm"
    },
    {
      "hash": "sha256-e5txtle0V/jlZ+5laxHe+k2o2xewHh66AVpDrj8yXlc=",
      "url": "_framework/System.Xml.Linq.pzw688hdq1.wasm"
    },
    {
      "hash": "sha256-3Ji5ahE2KwZ3kT5cM77zyBDTZE/pXs+WLvfVaT5SHfk=",
      "url": "_framework/System.Xml.ReaderWriter.k6b510fl7y.wasm"
    },
    {
      "hash": "sha256-GggwMr3AE147MGBM3KluNnokYN4z8PXOzqOHRYSJARo=",
      "url": "_framework/System.Xml.XDocument.mtfg4ozd64.wasm"
    },
    {
      "hash": "sha256-6BUeDh+wN+tE97n/xZ5FpCYyaVYitXH44JLzRcssrz8=",
      "url": "_framework/Websocket.Client.sntjl98ana.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-qooblhUjGrTirZibKOekbjiWznuoQcwOtSfCNk5bUEc=",
      "url": "_framework/dotnet.i98qtb0qz4.js"
    },
    {
      "hash": "sha256-jZddobLBM2C3lQhYQ61xSQJ/WqD3eQCO3RzoHGaOjx0=",
      "url": "_framework/dotnet.native.b6l13xorvf.js"
    },
    {
      "hash": "sha256-JTxXd17wbrHKV/375moHFUFc3a/ofVTPPqSTk6KwNj0=",
      "url": "_framework/dotnet.native.rw4kynp763.wasm"
    },
    {
      "hash": "sha256-QbnqrZGHtGq7wudS17/AYEPpH9JkphrsyVllD6JHmds=",
      "url": "_framework/dotnet.runtime.v06hirbjsv.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-r76yZB5+JKGVaT32HEUTeKNNaHoi/6VPrhGJwyz6dQ8=",
      "url": "_framework/netstandard.hoq1cin65t.wasm"
    },
    {
      "hash": "sha256-Umm1SnyEDbCOZTA79XV3A34ytu6GS+XLR4PDgR0vyiY=",
      "url": "bootstrap.min.css"
    },
    {
      "hash": "sha256-ltilJ/YZ4iUsXWYuP3L4nGzcwbwIKo3MOSsWgw+iaRQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-tKVwwWc/4VAeq3H8KW55mf/RSwkvQWZAxZ5+ycidfIA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-lrP0kOjCza0B6vFKi0TTBlFoTYYVmjN2hkrmDGAFAoQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
